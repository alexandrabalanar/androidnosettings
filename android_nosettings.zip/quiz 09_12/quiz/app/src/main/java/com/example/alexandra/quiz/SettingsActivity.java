package com.example.alexandra.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.vk.sdk.VKAccessToken;
import com.vk.sdk.VKCallback;
import com.vk.sdk.VKScope;
import com.vk.sdk.VKSdk;
import com.vk.sdk.api.VKApi;
import com.vk.sdk.api.VKError;
import com.vk.sdk.api.VKParameters;
import com.vk.sdk.api.VKRequest;
import com.vk.sdk.api.VKResponse;
import com.vk.sdk.api.methods.VKApiUsers;
import com.vk.sdk.api.model.VKApiUser;
import com.vk.sdk.api.model.VKUsersArray;

import org.json.JSONObject;

public class SettingsActivity extends AppCompatActivity implements View.OnClickListener {

    private String[] scope = new String[]{VKScope.WALL, VKScope.FRIENDS};
    private static  VKAccessToken Token=null;
    Boolean isLogged;
    Button VKbutton;
    Button VKOutButton;
    Button onButton;
    Button offButton;

    public static VKAccessToken getToken()

    {
        return Token;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        VKbutton = (Button) findViewById(R.id.vkButton);
        VKbutton.setOnClickListener(this);

        VKOutButton = (Button) findViewById(R.id.vkButtonOut);
        VKOutButton.setOnClickListener(this);

        onButton = (Button) findViewById(R.id.OnButton);
        onButton.setOnClickListener(this);
        offButton = (Button) findViewById(R.id.OffButton);
        offButton.setOnClickListener(this);
    }

    public void onClick(View v) {
        Intent intent;

        switch (v.getId()) {
            case R.id.vkButton: {

                VKSdk.login(this, scope);

                Toast.makeText(SettingsActivity.this, "you are logged in VK!", Toast.LENGTH_SHORT).show();
                isLogged=true;
                VKbutton.setVisibility(View.INVISIBLE);
                VKOutButton.setVisibility(View.VISIBLE);
                break;
            }
            case R.id.vkButtonOut:
                Toast.makeText(SettingsActivity.this, "you are logout in VK!", Toast.LENGTH_SHORT).show();
                VKSdk.logout();
                isLogged=false;
                VKbutton.setVisibility(View.VISIBLE);
                VKOutButton.setVisibility(View.INVISIBLE);


                break;

            case R.id.OnButton:
                int k=1;



                break;

            case R.id.OffButton:
                k=0;



        }
        }

        @Override
        protected void onActivityResult ( int requestCode, int resultCode, Intent data){
            if (!VKSdk.onActivityResult(requestCode, resultCode, data, new VKCallback<VKAccessToken>() {
                @Override
                public void onResult(VKAccessToken res) {
                    //Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_SHORT).show();
// Пользователь успешно авторизовался
                    Token=res;

                   // Toast.makeText(getApplicationContext(),"",Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onError(VKError error) {
                    Toast.makeText(getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
// Произошла ошибка авторизации (например, пользователь запретил авторизацию)
                }
            })) {
                super.onActivityResult(requestCode, resultCode, data);
            }
        }

}
