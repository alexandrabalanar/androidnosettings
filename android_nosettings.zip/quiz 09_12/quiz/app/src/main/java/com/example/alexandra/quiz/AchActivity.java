package com.example.alexandra.quiz;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AchActivity extends AppCompatActivity {
    ImageView oneImage;
    ImageView fiveImage;
    ImageView tenImage;
    TextView oneText;
    TextView fiveText;
    TextView tenText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ach);


        oneImage=findViewById(R.id.OneImage);
        fiveImage=findViewById(R.id.FiveImage);
        tenImage=findViewById(R.id.TenImage);

        oneText=findViewById(R.id.OneText);
        fiveText=findViewById(R.id.FiveText);
        tenText=findViewById(R.id.TenText);



        SharedPreferences mypref= getSharedPreferences("settings",MODE_PRIVATE);
         int g =mypref.getInt("oneimage",-1);
        if(g>0)
            try {
                oneImage.setVisibility(View.VISIBLE);
                oneText.setVisibility(View.VISIBLE);
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage());
            }
        if(g>4)
            try {
                fiveImage.setVisibility(View.VISIBLE);
                fiveText.setVisibility(View.VISIBLE);
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage());
            }

        if(g>9)
            try {
                tenImage.setVisibility(View.VISIBLE);
                tenText.setVisibility(View.VISIBLE);
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage());
            }
        if(g>19)
            try {
                fiveImage.setVisibility(View.VISIBLE);
                fiveText.setVisibility(View.VISIBLE);
            }
            catch (Exception e)
            {
                System.out.println(e.getMessage());
            }


    }
    public static int AddAchievement(int score)
    {
        return score;
    }
}
